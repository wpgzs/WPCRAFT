#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<ctime>
#include<sstream>
#include<windows.h>
#include<conio.h>
#include<fstream>
#include<cassert>
#include<cctype>
#include<dirent.h>
#include"resource.h"
//#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000) ? 1:0)
using namespace std;
int width=100,height=30;
HANDLE hout=GetStdHandle(STD_OUTPUT_HANDLE),hin=GetStdHandle(STD_INPUT_HANDLE);
struct
{
	string username;
} database;
const struct
{
	int white_black=15*16+0;
	int gray_white =8*16+15;
} colors;
void color(int col)
{
	SetConsoleTextAttribute(hout,col);
}
void gotoxy(short x, short y)
{
	COORD coord = {x, y};
	SetConsoleCursorPosition(hout,coord);
}
void cursor(bool visible)
{
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(hout,&CursorInfo);
	CursorInfo.bVisible = visible;
	SetConsoleCursorInfo(hout,&CursorInfo);
}
void cls()
{
	gotoxy(0,0);
}
enum Base64Option
{
    Base64Encoding = 0,
    Base64UrlEncoding = 1,

    KeepTrailingEquals = 0,
    OmitTrailingEquals = 2
};
string decode_base64(const  std::string sourceData, int options = Base64Encoding)
{
	unsigned int buf = 0;
	int nbits = 0;
	std::string tmp;
	tmp.resize((sourceData.size() * 3) / 4);
	int offset = 0;
	for (int i = 0; i < sourceData.size(); ++i)
	{
		int ch = sourceData.at(i);
		int d;
		if (ch >= 'A' && ch <= 'Z')
			d = ch - 'A';
		else if (ch >= 'a' && ch <= 'z')
			d = ch - 'a' + 26;
		else if (ch >= '0' && ch <= '9')
			d = ch - '0' + 52;
		else if (ch == '+' && (options & Base64UrlEncoding) == 0)
			d = 62;
		else if (ch == '-' && (options & Base64UrlEncoding) != 0)
			d = 62;
		else if (ch == '/' && (options & Base64UrlEncoding) == 0)
			d = 63;
		else if (ch == '_' && (options & Base64UrlEncoding) != 0)
			d = 63;
		else
			d = -1;
		if (d != -1)
		{
			buf = (buf << 6) | d;
			nbits += 6;
			if (nbits >= 8)
			{
				nbits -= 8;
				tmp[offset++] = buf >> nbits;
				buf &= (1 << nbits) - 1;
			}
		}
	}
	tmp.resize(offset);
	return tmp;
}
std::string encode_base64(const  std::string sourceData, int options = Base64Encoding)
{
	const char alphabet_base64[] = "ABCDEFGH" "IJKLMNOP" "QRSTUVWX" "YZabcdef"
	                               "ghijklmn" "opqrstuv" "wxyz0123" "456789+/";
	const char alphabet_base64url[] = "ABCDEFGH" "IJKLMNOP" "QRSTUVWX" "YZabcdef"
	                                  "ghijklmn" "opqrstuv" "wxyz0123" "456789-_";
	const char *const alphabet = options & Base64UrlEncoding ? alphabet_base64url : alphabet_base64;
	const char padchar = '=';
	int padlen = 0;

	std::string tmp;
	tmp.resize((sourceData.size() + 2) / 3 * 4);

	int i = 0;
	char *out = &tmp[0];
	while (i < sourceData.size())
	{
		// encode 3 bytes at a time
		int chunk = 0;
		chunk |= int((unsigned char)(sourceData.data()[i++])) << 16;
		if (i == sourceData.size())
		{
			padlen = 2;
		}
		else
		{
			chunk |= int((unsigned char)(sourceData.data()[i++])) << 8;
			if (i == sourceData.size())
				padlen = 1;
			else
				chunk |= int((unsigned char)(sourceData.data()[i++]));
		}

		int j = (chunk & 0x00fc0000) >> 18;
		int k = (chunk & 0x0003f000) >> 12;
		int l = (chunk & 0x00000fc0) >> 6;
		int m = (chunk & 0x0000003f);
		*out++ = alphabet[j];
		*out++ = alphabet[k];

		if (padlen > 1)
		{
			if ((options & OmitTrailingEquals) == 0)
				*out++ = padchar;
		}
		else
		{
			*out++ = alphabet[l];
		}
		if (padlen > 0)
		{
			if ((options & OmitTrailingEquals) == 0)
				*out++ = padchar;
		}
		else
		{
			*out++ = alphabet[m];
		}
	}
	assert((options & OmitTrailingEquals) || (out == tmp.size() + tmp.data()));
	if (options & OmitTrailingEquals)
		tmp.resize(out - tmp.data());
	return tmp;
}
COORD getCursorPos()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo(hout,&csbi);
	return csbi.dwCursorPosition;
}
LRESULT CALLBACK LoginDialogProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg)
	{
		case WM_CLOSE:
		{
			EndDialog(hwnd,0);
			break;
		}
		case WM_COMMAND:
		{
			if(true)
			{
				switch(LOWORD(wParam))
				{
					case IDC_BTN1:
					{
						char usernam[128]= { };
						char passwor[128]= { };
						GetWindowText(GetDlgItem(hwnd,IDC_EDT1),usernam,128);
						GetWindowText(GetDlgItem(hwnd,IDC_EDT2),passwor,128);
						ifstream fin("userdata");
						if(!fin.is_open())
						{
							MessageBox(hwnd,"Please register first","",0);
						}
						else
						{
							string un,pw;
							fin>>un>>pw;
							un=decode_base64(un);
							pw=decode_base64(pw);
							if((un==string(usernam))&&(pw==string(passwor))) database.username=usernam;
							else MessageBox(hwnd,"User name or password error","",0);
						}
						EndDialog(hwnd,0);
						break;
					}
					case IDC_BTN4:
					case IDC_BTN2:
					{
						EndDialog(hwnd,0);
						break;
					}
					case IDC_BTN3:
					{
						DialogBox(NULL,MAKEINTRESOURCE(IDD_DLG2),GetConsoleWindow(),LoginDialogProc);
						break;
					}
					case IDC_BTN5:
					{
						char usernam[128]= { };
						char passwor[128]= { };
						GetWindowText(GetDlgItem(hwnd,IDC_EDT3),usernam,128);
						GetWindowText(GetDlgItem(hwnd,IDC_EDT4),passwor,128);
						ofstream fout("userdata");
						fout<<encode_base64(usernam)<<endl<<encode_base64(passwor);
						EndDialog(hwnd,0);
						break;
					}
				}
			}
			break;
		}
		default:
		{
			return false;
			break;
		}
	}
	return true;
}
template<class Type>
string toString(Type t)
{
	ostringstream sout;
	sout<<t;
	return sout.str();
}
void Line(string str,int col=colors.white_black)
{
	int start=(width-str.size())/2;
	for(int i=1; i<=start; i++) cout<<" ";
	color(col);
	cout<<str<<endl;
	color(colors.white_black);
}
string GetTime()
{
	time_t timep;
	time (&timep);
	char tmp[64];
	strftime(tmp,sizeof(tmp),"%Y%m%d",localtime(&timep));
	return tmp;
}
bool endDay()
{
	string endday="20230701";
	if(GetTime()>endday)
	{
		return true;
	}
	return false;
}
void LeftLine(string s)
{
	cout<<s<<endl;
}
void RightLine(string s)
{
	for(int i=1; i<=width-s.size(); i++) cout<<" ";
	cout<<s<<endl;
}
void showStartMenu(int a)
{
	system("cls");
	if(a==1)
	{
//		cout<<"People who have contributed to this game are:\n";
		Line("People who have contributed to this game are:");
		Line("WP_Studio[https://www.luogu.com.cn/user/671715]");
		cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl
		    <<endl<<endl<<endl<<endl<<endl;
		Line("G to next");
		int t;
		while(1)
		{
			t=getch();
			if(t=='g' || t=='G')
			{
				break;
			}
		}
	}
	if(a==2)
	{
		Line("This is the Second version of WPCRAFT");
		cout<<endl;
		Line("Add registered window");
		Line("Add login window");
		Line("User data is encryption");
		cout<<endl;
		Line("Finally, thank you for your play");
		cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
		Line("S to start");
		int t;
		while(1)
		{
			t=getch();
			if(t=='s' || t=='S')
			{
				break;
			}
		}
	}
}
void showMainMenu()
{
//	if(database.username=="") RightLine("Login[L]");
//	else                      RightLine("Welcome "+database.username);
	(database.username=="" ? RightLine("Login[L]") : RightLine("Welcome "+database.username));
	Line("W        W       W PPPPPP   CCCCC RRRRRR     A     FFFFFF TTTTTTT");
	Line(" W      W W     W  P    P  C      R    R    A A    F         T   ");
	Line("  W    W   W   W   PPPPPP C       RRRRRR   A   A   FFFFFF    T   ");
	Line("   W  W     W W    P       C      RRR     AAAAAAA  F         T   ");
	Line("    WW       W     P        CCCCC R  RRR A       A F         T   ");
	cout<<endl<<endl<<endl<<endl;
	Line("Start Play[F]",colors.gray_white);
	cout<<endl<<endl;
	Line("Online Play [V]",colors.gray_white);
	cout<<endl<<endl;
	Line("WP_Studio Community[G]",colors.gray_white);
	cout<<endl<<endl;
	Line("Feedback[T]",colors.gray_white);
	gotoxy(0,height-1);
	cout<<("All rights reserved by WP-Studio");
}
void login()
{
	(database.username=="" ?
	 DialogBox(NULL,MAKEINTRESOURCE(IDD_DLG1),GetConsoleWindow(),LoginDialogProc) :
	 0);
}
void playGame()
{
	cout<<"Waiting...";
	getch();
}
void onlineGame()
{
	cout<<"Waiting...";
	getch();
}
int main()
{
	if(endDay()) return 0;
	cursor(false);
	system("color f0");
	system(("mode con cols="+toString(width)+" lines="+toString(height)).c_str());
	system("title WPCRAFT 1.2 English");
	showStartMenu(1);
	showStartMenu(2);
	system("cls");
	while(1)
	{
		int com='?';
		cls();
		showMainMenu();
		com=getch();
		switch(com)
		{
			case 'l':
			case 'L':
			{
				system("cls");
				login();
				break;
			}
			case 'f':
			case 'F':
			{
				system("cls");
				playGame();
				break;
			}
			case 'v':
			case 'V':
			{
				system("cls");
				onlineGame();
				break;
			}
			case 'g':
			case 'G':
			{
				system("start https://www.luogu.com.cn/team/41333");
				break;
			}
			case 't':
			case 'T':
			{
				system("start https://www.luogu.com.cn/chat?uid=671715");
				break;
			}
		}
	}
	return 0;
}

